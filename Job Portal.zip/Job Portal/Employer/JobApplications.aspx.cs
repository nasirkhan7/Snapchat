﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employer_JobApplications : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void gvApplications_RowDataBound(object sender, GridViewRowEventArgs e)
    {
   
    }

    protected void gvApplications_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string li = e.CommandArgument.ToString();
        decimal id;
        Decimal.TryParse(li, out id);

        byte[] bytes;
        string constr = ConfigurationManager.ConnectionStrings["JobPortalConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select CV from Applications where Application_Id=@Id";
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    sdr.Read();
                    bytes = (byte[])sdr["CV"];
                    //contentType = sdr["ContentType"].ToString();
                    //fileName = sdr["Name"].ToString();
                }
                con.Close();
            }
        }

        if (e.CommandName.Equals("View"))
        {

            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Type", "application/pdf");
            Response.AddHeader("Content-Disposition", "inline");
            Response.BinaryWrite(bytes);
            Response.End();


        }

        if (e.CommandName.Equals("Download"))
        {

            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.ContentType = "application/pdf";
            Response.AppendHeader("Content-Disposition", "attachment; filename=CV.pdf");
            Response.BinaryWrite(bytes);
            Response.End();
        }

    }
    

    protected void SqlDSApplications_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        string eid = Session["ID"].ToString();
        SqlParameter emid = new SqlParameter("@Member_ID", eid);
        e.Command.Parameters.Add(emid);
    }
}