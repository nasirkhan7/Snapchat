﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
public partial class Employer_EmployerLogin : System.Web.UI.Page
{
    DAO dao = new DAO();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void SubmitButtonClick(object Sender, EventArgs e)
    {
        dao.OpenConnection();

        string query = "select *  from Members " +
            "where Member_Email=@Email and Member_Password=@Password";
        SqlCommand cmd = new SqlCommand(query, dao.Connection);

        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            while (dr.Read())
            {

                Session["ID"] = dr["Member_ID"];
                Session["user"] = dr["Member_FName"];
                Session["Email"] = dr["Member_Email"];
            }
            //lblCheck.Text = Session["user"].ToString();
            Response.Redirect("EmployerDashboard.aspx");
        }
        else
        {
            lblCheck.ForeColor = Color.Red;
            lblCheck.Text = " Invalid Login.";
        }
        dao.CloseConnection();
    }
}