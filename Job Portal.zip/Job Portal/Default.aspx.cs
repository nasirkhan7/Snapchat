﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Drawing;
using System.Configuration;
using System.Web.Security;

public partial class Default2 : System.Web.UI.Page
{
    DAO dao;
    protected void Page_Load(object sender, EventArgs e)
    {
        dao = new DAO();
        getCities();
        
    }
    private void getCities()
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = " Select * From Cities";
        cmd.Connection = dao.Connection;
        dao.OpenConnection();
        DataTable dt = new DataTable();
        dt.Load(cmd.ExecuteReader());
        dao.CloseConnection();
        DropDownList ddCity = (DropDownList)fvs.FindControl("ddCity");
        if (ddCity != null)
        {
            ddCity.DataSource = dt;
            ddCity.DataTextField = "City_Name";
            ddCity.DataValueField = "City_ID";
            ddCity.DataBind();
        }

    }
    protected void SqlDSJobs_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        
    }

    protected void SqlDSJobs_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {

        int rows = e.AffectedRows;
        
        if (rows > 0)
        {
        
        }
        else
        {
            this.rptSearchJobs.Visible = true;
            //Label Error = (Label)this.rptSearchJobs.FindControl("lblError");
            this.lblError.Visible = true;
        }

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        TextBox Title = (TextBox)this.fvs.FindControl("txtTitle");
        string jt = Title.Text;
        DropDownList ddCity = (DropDownList)fvs.FindControl("ddCity");
        string city = ddCity.SelectedValue.Trim();
        Session["JobTitle"] = jt;
        Session["City"] = city;
        Response.Redirect("SearchJobs.aspx");
     }
    
}