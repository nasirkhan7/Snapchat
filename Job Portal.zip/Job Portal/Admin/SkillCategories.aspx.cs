﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_SkillCategories : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            lblname.Text = Session["user"].ToString();
        }
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["id"] != null)
            {
                this.sqlDSSkillCategories.FilterExpression = "Skill_Category_ID=" +
                Request.QueryString["id"];
                //this.fvAdmin.DataSource = SqlDSIndustries;
                this.fvSkillCategories.DataBind();
                this.fvSkillCategories.ChangeMode(FormViewMode.Edit);
                //  this.gvSkillCategories.Visible = true;
                this.gvSkillCategories.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvSkillCategories.Enabled = true;
            }
            this.gvSkillCategories.DataBind();
            this.gvSkillCategories.Visible = true;
        }
    }

    protected void btnAddNew_Click(object sender, EventArgs e)
    {
        this.fvSkillCategories.ChangeMode(FormViewMode.Insert);
        this.btnAddNew.Enabled = false;
        this.gvSkillCategories.Enabled = this.btnAddNew.Enabled;

    }

    #region Inserting
    protected void fvSkillCategories_ItemInserting(object sender
        , FormViewInsertEventArgs e)
    {
        foreach(DictionaryEntry entry in e.Values)
        {
            if (entry.Value.Equals(""))
            {
                // Use the Cancel property to cancel the 
                // insert operation.
                e.Cancel = true;

                lblStatus.Text += "Please enter a value for the " +
                  entry.Key.ToString() + " field.<br/>";

            }
            //Response.Write(entry.Key+": "+entry.Value+"<br />");
        }
    }

    protected void sqlDSSkillCategories_Inserting(object sender
        , SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Skill_Category_ID), 0) +1 From Skill_Categories";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        SqlParameter insertedKey = new SqlParameter("@Skill_Category_ID", id);
        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(insertedKey);
            //e.Command.Parameters["@Industry_ID"].Value = id;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

        //sql = "INSERT INTO Skill_Categories "

        //     + "(Skill_Category_ID, Skill_Category_Name) "
        //    + " VALUES(@Skill_Category_ID, @Skill_Category_Name)";

        //Dictionary<string, object> params1 = new Dictionary<string, object>();
        //KeyValuePair<string, decimal> idParam = new KeyValuePair<string, decimal>("@Skill_Category_ID", id);
        //KeyValuePair<string, decimal> idParam = new KeyValuePair<string, decimal>("@Skill_Category_ID", id);

    }

    protected void sqlDSSkillCategories_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {
        if(e.Exception!=null)
        {
            Response.Write(e.Exception.Message);
           
        }
    }

    protected void fvSkillCategories_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                lblStatus.Text = "Record inserted successfully.";
                lblStatus.ForeColor = System.Drawing.Color.Green;
                this.gvSkillCategories.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvSkillCategories.Enabled = true;
            }
            else
            {
                lblStatus.Text = "An error occurred during the insert operation.";
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            // Insert the code to handle the exception.
            lblStatus.Text = e.Exception.Message;
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }
    #endregion Inserting
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        this.gvSkillCategories.AllowPaging = true;
        this.btnAddNew.Enabled = true;
        this.gvSkillCategories.Enabled = true;

        this.gvSkillCategories.DataBind();
        this.gvSkillCategories.Visible = true;
    }
}