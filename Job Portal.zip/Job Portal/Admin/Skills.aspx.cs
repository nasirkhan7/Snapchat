﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Collections;

public partial class Admin_Skills : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            lblname.Text = Session["user"].ToString();
        }
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["id"] != null)
            {
                this.SqlDSSkills.FilterExpression = "Skill_ID=" +
                Request.QueryString["id"];
                //this.fvAdmin.DataSource = SqlDSIndustries;
                this.fvSkills.DataBind();
                this.fvSkills.ChangeMode(FormViewMode.Edit);
                //  this.gvSkillCategories.Visible = true;
                this.gvSkills.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvSkills.Enabled = true;
            }
            this.gvSkills.DataBind();
            this.gvSkills.Visible = true;
        }

    }
    protected void btnAddNew_Click(object sender, EventArgs e)
    {
        this.fvSkills.ChangeMode(FormViewMode.Insert);
        this.btnAddNew.Enabled = false;
        this.gvSkills.Enabled = this.btnAddNew.Enabled;
    }
    protected void fvSkills_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        foreach (DictionaryEntry entry in e.Values)
        {
            if (entry.Value.Equals(""))
            {
                // Use the Cancel property to cancel the 
                // insert operation.
                e.Cancel = true;

                lblStatus.Text += "Please enter a value for the " +
                  entry.Key.ToString() + " field.<br/>";

            }
            //Response.Write(entry.Key+": "+entry.Value+"<br />");
        }
    }

    protected void SqlDSSkills_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Skill_ID), 0) +1 From Skills";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        //SqlParameter insertedKey = new SqlParameter("@Skill_ID", id);
        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            //e.Command.Parameters.Add(insertedKey);
            e.Command.Parameters["@Skill_ID"].Value = id;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }

    protected void SqlDSSkills_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            Response.Write(e.Exception.Message);

        }
    }

    protected void fvSkills_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                lblStatus.Text = "Record inserted successfully.";
                lblStatus.ForeColor = System.Drawing.Color.Green;
                this.gvSkills.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvSkills.Enabled = true;
            }
            else
            {
                lblStatus.Text = "An error occurred during the insert operation.";
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            // Insert the code to handle the exception.
            lblStatus.Text = e.Exception.Message;
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        this.gvSkills.AllowPaging = true;
        this.btnAddNew.Enabled = true;
        this.gvSkills.Enabled = true;
        this.gvSkills.DataBind();
        this.gvSkills.Visible = true;
    }
}