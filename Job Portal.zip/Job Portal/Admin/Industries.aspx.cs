﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Industries : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            lblname.Text = Session["user"].ToString();
        }

        if (!Page.IsPostBack)
        {
            if(Request.QueryString["id"]!=null)
            {
                this.SqlDSIndustries.FilterExpression = "Industry_ID=" +
                Request.QueryString["id"];
                //this.fvAdmin.DataSource = SqlDSIndustries;
                this.fvIndustries.DataBind();
                this.fvIndustries.ChangeMode(FormViewMode.Edit);
                this.gvIndustries.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvIndustries.Enabled = true;
            }
            this.gvIndustries.DataBind();
            this.gvIndustries.Visible = true;
        }
    }
    protected void btnAddNew_Click(object sender, EventArgs e)
    {
        this.fvIndustries.ChangeMode(FormViewMode.Insert);
        this.btnAddNew.Enabled = false;
        this.gvIndustries.Enabled = this.btnAddNew.Enabled;

    }


    protected void fvIndustries_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        foreach (DictionaryEntry entry in e.Values)
        {
            if (entry.Value.Equals(""))
            {
                // Use the Cancel property to cancel the 
                // insert operation.
                e.Cancel = true;
                
                lblStatus.Text += "Please enter a value for the " +
                  entry.Key.ToString() + " field.<br/>";

            }
            //Response.Write(entry.Key + ": " + entry.Value + "<br />");
        }
    }

    protected void SqlDSIndustries_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Industry_ID), 0) +1 From Industries";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        SqlParameter insertedKey = new SqlParameter("@Industry_ID", id);

        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(insertedKey);
            //e.Command.Parameters["@Industry_ID"].Value = id;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

      
    }


    protected void SqlDSIndustries_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            Response.Write(e.Exception.Message);

        }
    }

    protected void fvIndustries_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                lblStatus.Text = "Record inserted successfully.";
                lblStatus.ForeColor = System.Drawing.Color.Green;
                this.gvIndustries.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvIndustries.Enabled = true;
            }
            else
            {
                lblStatus.Text = "An error occurred during the insert operation.";
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            // Insert the code to handle the exception.
            lblStatus.Text = e.Exception.Message;
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        this.gvIndustries.AllowPaging = true;
        this.btnAddNew.Enabled = true;
        this.gvIndustries.Enabled = true;
        this.gvIndustries.DataBind();
        this.gvIndustries.Visible = true;
    }
}