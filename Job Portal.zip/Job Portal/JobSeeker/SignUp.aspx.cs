﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Net.Mail;
using System.Net;

public partial class SignUp : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        this.fvJobSeeker.ChangeMode(FormViewMode.Insert);
        //TextBox txtPass = (TextBox)fvMembers.FindControl("txtMemberPassord"); ;
        //txtPass.Attributes["type"] = "password";
        ////con = new SqlConnection("Data Source=DESKTOP-B83U7C5\\SQLEXPRESS;Initial Catalog=JobPortal;Integrated Security=True");
        //con.Open();
        //string query = "select * from Member";
        //SqlDataAdapter sda = new SqlDataAdapter(query, con);
        //DataTable data = new DataTable();
        //sda.Fill(data);
        //Repeater2.DataSource = data;
        //Repeater2.DataBind();
    }

    protected void fvJobSeeker_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        foreach (DictionaryEntry entry in e.Values)
        {
            //Response.Write(entry.Key+": "+entry.Value+"<br />");
        }
    }

    protected void SqlDSJobSeeker_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Member_ID), 0) +1 From Members";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        SqlParameter insertedKey = new SqlParameter("@Member_ID", id);
        string r = "J";
        SqlParameter role = new SqlParameter("@Role", r);

        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(role);
            e.Command.Parameters.Add(insertedKey);
            //e.Command.Parameters["@Member_ID"].Value = id;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    private void insertJobSeeker()
    {
        DAO dao = new DAO();
        String sql = "Select IsNull(Max(Job_Seeker_ID), 0) +1 From Job_Seeker_Profiles";
        decimal jid = (decimal)dao.ExecuteScalar(sql);

        sql = "Select Max(Member_ID) From Members";
        decimal mid = (decimal)dao.ExecuteScalar(sql);

        SqlParameter emid = new SqlParameter("@Job_Seeker_ID", jid);
        SqlParameter memid = new SqlParameter("@Member_ID", mid);
        sql = "INSERT INTO Job_Seeker_Profiles(Job_Seeker_ID,Member_ID) VALUES" +
            "(@Job_Seeker_ID,@Member_ID)";
        SqlCommand cmd = new SqlCommand(sql, dao.Connection);
        try
        {
            cmd.Parameters.Add(emid);
            cmd.Parameters.Add(memid);
            dao.OpenConnection();
            cmd.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        dao.CloseConnection();
    }
    protected void SqlDSJobSeeker_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            Response.Write(e.Exception.Message);
        }
        else
        {
            insertJobSeeker();
        }
    }

    protected void fvJobSeeker_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                verifyEmail();
                Response.Write("<script> alert('Inserted!!')</script>");
                //this.fvMembers.ChangeMode(FormViewMode.Insert);
                //lblStatus.Text = "Record inserted successfully.";
                //lblStatus.ForeColor = System.Drawing.Color.Green;

                Response.Redirect("Login.aspx");
                //lblStatus.Text = "Record inserted successfully.";
                //lblStatus.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                //Label status = (Label)fvMembers.FindControl("lblStatus");
                lblStatus.Text = "An error occurred during the insert operation.";
                lblStatus.ForeColor = System.Drawing.Color.Red;
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            // Insert the code to handle the exception.
            //Label status = (Label)fvMembers.FindControl("lblStatus");
            lblStatus.Text = e.Exception.Message;
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }

    protected void verifyEmail()
    {
        string username = string.Empty;
        string password = string.Empty;

        DAO dao = new DAO();
        try
        {
            string query = "SELECT Member_FName,Member_LName, Member_Password " +
                "FROM Members WHERE Member_Email = @Email";
            SqlCommand cmd = new SqlCommand(query, dao.Connection);

            TextBox email = (TextBox)fvJobSeeker.FindControl("txtMemberEmail");
            string REmail = email.Text.Trim();
            cmd.Parameters.AddWithValue("@Email", REmail);
            dao.OpenConnection();
            SqlDataReader sdr = cmd.ExecuteReader();

            while (sdr.Read() == true)
            {
                username = sdr["Member_FName"].ToString();
                password = sdr["Member_Password"].ToString();
            }

            dao.CloseConnection();

            if (!string.IsNullOrEmpty(password))
            {
                string SEmail = "smartjobportal2022@gmail.com";
                MailMessage mm = new MailMessage(SEmail, REmail);
                mm.Subject = "Verification of Email";
                mm.Body = string.Format("<h2>Verification of E-mail to finish signing up</h2>" +
                    "{1},<br /><br /> " +
                    "Thank you for joining this platform. <br/>" +
                    "Hope this platform" +
                    " will help you in finding best job according to you " +
                    "experience, skills & qualifications. <br/> The email you register is {0}" +
                    "<br /> " +
                    "<h2>Thank You</h2>.</div></body></html>", REmail, username.ToUpper());
                mm.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential();
                NetworkCred.UserName = SEmail;
                NetworkCred.Password = "zrduqwvehzfblkah";
                smtp.UseDefaultCredentials = true;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Credentials = NetworkCred;
                smtp.Port = 587;
                try
                {
                    smtp.Send(mm);
                }
                catch (Exception ex)
                {
                    ex.Message.ToString();
                }

                Response.Write("<script>alert('Check your Email for Verification')</script>");

            }
            else
            {
                //Response.Write("<script>alert('Error')</script>");
                lblStatus.ForeColor = System.Drawing.Color.Red;
                lblStatus.Text = REmail + " Email address is not correct";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
            Response.Write("<script>alert('Error')</script>");
        }


    }
}