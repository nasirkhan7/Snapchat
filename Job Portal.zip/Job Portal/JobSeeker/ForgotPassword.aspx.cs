﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Drawing;
using System.Configuration;
using System.Data.SqlClient;
public partial class ForgotPassword : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void SendEmail(object sender, EventArgs e)
    {
        string username = string.Empty;
        string password = string.Empty;

        DAO dao = new DAO(); 
        try
        {
            string query = "SELECT Member_FName,Member_LName, Member_Password " +
                "FROM Members WHERE Member_Email = @Email";
            SqlCommand cmd = new SqlCommand(query,dao.Connection);
            string REmail = txtEmail.Text.Trim();
            cmd.Parameters.AddWithValue("@Email",REmail);
            dao.OpenConnection();
            SqlDataReader sdr = cmd.ExecuteReader();

            while (sdr.Read() == true)
            {
                username = sdr["Member_FName"].ToString();
                password = sdr["Member_Password"].ToString();
            }

            dao.CloseConnection();

            if (!string.IsNullOrEmpty(password))
            {
                string SEmail = "smartjobportal2022@gmail.com";
                MailMessage mm = new MailMessage(SEmail,REmail);
                mm.Subject = "Password Recovery";
                mm.Body = string.Format("<h2>Hi</h2>{1},<br /><br />Your password is " +
                    "{2}.<br /><br />If you did not request this password change," +
                    "please ignore this email- your password will remain uneffected." +
                    "<br /><h2>Thank You</h2>.</div></body></html>", SEmail, username, 
                    password);
                mm.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential();
                NetworkCred.UserName = SEmail;
                NetworkCred.Password = "zrduqwvehzfblkah";
                smtp.UseDefaultCredentials = true;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Credentials = NetworkCred;
                smtp.Port = 587;
                try
                {
                    smtp.Send(mm);
                }catch(Exception ex)
                {
                   lblMessage.Text= ex.Message.ToString();
                    lblMessage.ForeColor = Color.Red;
                }
                lblMessage.ForeColor = Color.Green;
                lblMessage.Text = "Password has been sent to " + txtEmail.Text +
                    " Check your inbox";
                txtEmail.Text = "";

            }
            else
            {
                lblMessage.ForeColor = Color.Red;
                lblMessage.Text = txtEmail.Text + " This email address does not " +
                    "match our records.";
            }
        }
        catch (Exception ex)
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = ex.Message.ToString();
            //Response.Write("<script>alert()</script>");
        }

    }
}