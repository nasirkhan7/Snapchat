﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class SearchJobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void SqlDSJobs_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

        try
        {
            if (Session["JobTitle"] != null && Session["City"] != null)
            {
                string jt = Session["JobTitle"].ToString();
                string city = Session["City"].ToString();

                SqlParameter JobTitle = new SqlParameter("@JobTitle", jt);
                SqlParameter ciid = new SqlParameter("@City_ID", city);

                e.Command.Parameters.Add(JobTitle);
                e.Command.Parameters.Add(ciid);
                this.rptSearchJobs.Visible = true;
            }
            else
            {
                this.rptSearchJobs.Visible = true;
                //Label Error = (Label)this.rptSearchJobs.FindControl("lblError");
                //Error.Visible = true;
                this.lblError.Text = "No Job Searched";

            }

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }

    }

    protected void SqlDSJobs_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            int rows = e.AffectedRows;
            //Response.Write("<script>Jobs found given below</script>");
            //this.lblStatus.Text = "Jobs found given below";
            // this.lblStatus.ForeColor = Color.Green;

        }
        else
        {
            this.rptSearchJobs.Visible = true;
            //Label Error = (Label)this.rptSearchJobs.FindControl("lblError");
            this.lblError.Visible = true;
        }

    }
    protected void ValidateUser(object sender, EventArgs e)
    {
            string email = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            Session["email"] = email;
            Label JobId = (Label)(rptSearchJobs.Items[0]).FindControl("lblId");
            string jid = JobId.Text.Trim();
            Session["JobId"] = jid;
            int userId = 0;
            string constr = ConfigurationManager.ConnectionStrings["JobPortalConnectionString"].
                ConnectionString;
            string query;
            using (SqlConnection con = new SqlConnection(constr))
            {
                query = "select *  from Members " +
                "where Member_Email=@Email and Member_Password=@Password";

                SqlCommand cmd = new SqlCommand();

                cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", password);
                con.Open();
                SqlDataAdapter sqa = new SqlDataAdapter(query, con);
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                    //Session["user"] = dr["Member_FName"];
                    Session["ProfileID"] = dr["Member_ID"];
                        Session["FName"] = dr["Member_FName"];
                        Session["LName"] = dr["Member_LName"];
                        Session["Mobile"] = dr["Member_Contact"];

                    }
                    //lblCheck.Text = Session["user"].ToString();
                    Response.Redirect("JobSeeker/ApplyforJob.aspx");
                }
                else
                {
                    dvMessage.Visible = true;
                    lblMessage.Text = "Username and/or password is incorrect.";
                }
                con.Close();
            }
        

    }


    protected void rptSearchJobs_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (Session["user"] != null)
        {
            //HtmlAnchor lnk = e.Item.FindControl("lnkLogin") as HtmlAnchor;
            //lnk.Attributes["style"] = "display:none";
            //HtmlAnchor lnkA = e.Item.FindControl("lnkApply") as HtmlAnchor;
            //    lnkA.Attributes["style"] = "display:block";   
        }
        else
        {
            //HtmlAnchor lnkA = e.Item.FindControl("lnkApply") as HtmlAnchor;
            //lnkA.Attributes["style"] = "display:none";
        }
    }
}